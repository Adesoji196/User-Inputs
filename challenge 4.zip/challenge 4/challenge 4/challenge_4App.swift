//
//  challenge_4App.swift
//  challenge 4
//
//  Created by Turma02-1 on 16/10/26.
//

import SwiftUI

@main
struct challenge_4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
