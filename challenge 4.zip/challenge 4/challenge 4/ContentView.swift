//
//  ContentView.swift
//  challenge 4
//
//  Created by Turma02-1 on 16/10/26.
//

import SwiftUI

struct ContentView: View {
    
    @State private var distance: Double = 10
    @State private var time: Double = 10
    @State private var speed: Double = 0
    @State private var imageVariable: String = "questionmark"
    
    
    var body: some View {
        VStack {
            
            Text("Type your distance in km:") //the distance need to be in KM
            TextField("Enter a number", value: $distance,format: .number)
                .keyboardType(.decimalPad)
                .textContentType(.oneTimeCode)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
            Text("Type your time in h:") //this one must be in HOURS
            TextField("Enter a number", value: $time,format: .number)
                .keyboardType(.decimalPad)
                .textContentType(.oneTimeCode)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
            
            Button("Tap Me") {
                
                speed = distance / time
                
                if speed <= 9.99 {
                    imageVariable = "turtle"
                }
                else if speed > 10 && speed <= 29.99 {
                    imageVariable = "elephant"
                }
                else if speed > 30 && speed <= 69.99 {
                    imageVariable = "ostrich"
                    
                }
                else if speed > 70 && speed <= 89.99 {
                    imageVariable = "lion"
                    
                    
                } else {
                    imageVariable = "leopard"
                }
                
                
                
                
                
            }
            Text("\(speed) km/h")
            Image(imageVariable)
                .resizable()
                .frame(width: 300, height: 300)
            
        }
        
    }
}

#Preview {
    ContentView()
}
